 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"

uint16_t ms=0;
uint16_t sec=0;

void timer_callback(void)
{
    ms++;
    if (ms>1000) 
    {
        ms -= 1000;
        sec++;
    //    IO_RA2_Toggle();
    }
}

void eusart_callback(void)
{
//    ms++;
}

uint8_t send_message(char * my_message){
    printf("%s",my_message);
    return 1;
}
        
#define TCA_ADDR  0x70    // I2C address of the TCA9548A multiplexer
#define VCNL_ADDR 0x60    // I2C address of the VCNL4035X01 sensor
#define ALS_CONF 0x00
#define ALS_DATA 0x0B

#define AVERAGE_WINDOW 5
#define BUFSIZE 4
#define MSGSIZE 64
#define TEAMSIZE 4
#define MSGTESTSIZE 64
#define MSGTESTCHAR 0

const char my_id='m';
const char team_ids[TEAMSIZE+1] = "fhlm";
const char bc = 'X';
char buffer_in[BUFSIZE+1];
char message_in[MSGSIZE+1];
char message_out[MSGSIZE+1];
char mode = '0', LB = '0', RB = '0'; 
int s1 = 450, s2 = 7000, s3 = 500, s4 = 6, mv = 2500;
int flag = 1;
uint16_t lux1_buffer[AVERAGE_WINDOW] = {0};
uint16_t lux2_buffer[AVERAGE_WINDOW] = {0};
uint8_t lux1_index = 0;
uint8_t lux2_index = 0;
uint32_t lux1_sum = 0;
uint32_t lux2_sum = 0;

uint8_t datam[8], datal[8], input[10], output[10];

uint16_t update_lux1_average(uint16_t new_reading) {
    lux1_sum -= lux1_buffer[lux1_index];
    lux1_buffer[lux1_index] = new_reading;
    lux1_sum += new_reading;
    lux1_index = (lux1_index + 1) % AVERAGE_WINDOW;
    return lux1_sum / AVERAGE_WINDOW;
}

uint16_t update_lux2_average(uint16_t new_reading) {
    lux2_sum -= lux2_buffer[lux2_index];
    lux2_buffer[lux2_index] = new_reading;
    lux2_sum += new_reading;
    lux2_index = (lux2_index + 1) % AVERAGE_WINDOW;
    return lux2_sum / AVERAGE_WINDOW;
}

void init_Sensors()
{
 
        input[0] = '\0';
        input[1] = '\0';
        input[0] = 0b00000000;
        I2C1_Write(VCNL_ADDR,input,1);
        I2C2_Write(VCNL_ADDR,input,1);
        __delay_ms(10);
        input[0] = '\0';
        input[1] = 0b00011000;
        input[0] = 0b0000000;
        I2C1_Write(VCNL_ADDR,input,2);
        I2C2_Write(VCNL_ADDR,input,2);
        __delay_ms(10);
        input[0] = '\0';
        input[1] = '\0';
}

void read_Sensors()
{

    input[0] = '\0';
    input[0] = 0b00001011;
    I2C1_WriteRead(VCNL_ADDR, input, 1, datam,2);
    I2C2_WriteRead(VCNL_ADDR, input, 1, datal,2);
    __delay_ms(10);
   
}

uint16_t scale_lux(uint16_t raw_lux) {
    return ((uint32_t)raw_lux * 9999) / 65535;
}


//char stream_in[]="-----AZcb34567890YB-----------AZcd34567890YB--AZed34567890YB--AZdz34567890YB---AZed1234567890123456789012345678901234567890123456789012345678YB-";
//char read_char(void){
//    static int ii=0;
//    char c = stream_in[ii];
//    ii++;
//    if (ii>=(sizeof stream_in)-1)
//    {ii=0;}
//    return c;
//}

void fill_string(char * mystring,char value,unsigned int size){
    for (int ii=0;ii<size;ii++){
        mystring[ii]=value;
    }
}

unsigned int find_char(char * mystring, char value,unsigned int size){
    char c=0;
    for (int ii=0;ii<size;ii++){
        c= mystring[ii];
//        printf("%c,%c;",value,mystring[ii]);
        if (c==value){
            return 1;
        }
    }
    return 0;
}

void handle_message(unsigned int ii){
    message_in[ii-2]=0;
   // printf("AZbaPIC: handling: %sYB",message_in+4);
}


int main(void)
{

    char c=0;
    unsigned int buffer_ii=0;
    unsigned int buffer_last_ii = 0;
    unsigned int message_ii=0;
    unsigned int message_last_ii=0;
    buffer_in[BUFSIZE]=0;
    message_in[MSGSIZE]=0;
    unsigned int message_incoming=0;
    fill_string(buffer_in,'a',BUFSIZE);
    fill_string(message_in,'_',MSGSIZE);
    message_in[MSGTESTSIZE]=MSGTESTCHAR;

    uint16_t ms_last=0;
    uint16_t sec_last=0;
    SYSTEM_Initialize();
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts 
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts 
    // Use the following macros to: 

    // Enable the Global Interrupts 
    INTERRUPT_GlobalInterruptEnable(); 

    // Disable the Global Interrupts 
    //INTERRUPT_GlobalInterruptDisable(); 

    // Enable the Peripheral Interrupts 
    INTERRUPT_PeripheralInterruptEnable(); 

    // Disable the Peripheral Interrupts 
    //INTERRUPT_PeripheralInterruptDisable(); 
    TMR1_Initialize();
    TMR1_Start();
    TMR1_TMRInterruptEnable();

    TMR1_OverflowCallbackRegister(timer_callback);

    EUSART1_Initialize();
    EUSART1_Enable();
//    EUSART1_TransmitEnable();
//    EUSART1_ReceiveEnable();
//    EUSART1_TransmitInterruptEnable();
//    EUSART1_ReceiveInterruptEnable();
//    
//    UART1_RxCompleteCallbackRegister(eusart_callback);

//sprintf(message_out,"AZNKK2YB");
//    printf("%lu", sizeof buffer_in);
    
    I2C1_Initialize();
    I2C2_Initialize();// Initialize I2C1 module
    __delay_ms(500);
    init_Sensors();
    __delay_ms(2000);
    uint16_t lux1, lux2; 
      
while (1)
{
    if (EUSART1_IsRxReady())
    {
        c = EUSART1_Read();
        buffer_in[buffer_ii] = c;

        // Message Start Detected
        if (buffer_in[buffer_last_ii] == 'A' && c == 'Z')
        {
            message_incoming = 1;
            message_ii = 0;
            fill_string(message_in, '_', MSGSIZE);
            message_in[0] = 'A';
            message_ii = 1;
        }

        // Store Incoming Message
        if (message_incoming)
        {
            message_in[message_ii++] = c;
            
            if (message_ii == 4)
            {
                if(!(find_char(team_ids,buffer_in[buffer_last_ii],TEAMSIZE)))
                {
                    printf("AZmhPIC:SenderNotinTeamYB");
                    message_incoming = 0;
                    fill_string(message_in,'_',MSGSIZE);
                }
                if (message_in[3] == bc)
                {
                   // printf("AZmhPIC:BroadcastingYB");
                    flag = 0;
                }
                else if (!(find_char(team_ids,c,TEAMSIZE)))
                {
                    printf("AZmhPIC:RecieverNotinTeamYB");
                    message_incoming = 0;
                    fill_string(message_in,'_',MSGSIZE);
                }
                if ((message_in[2] == my_id) && flag == 1)
                {
                    printf("AZmhPIC:DuplicateMessageDeletedYB");
                    message_incoming = 0;
                    fill_string(message_in,'_',MSGSIZE);
                }
                
            }
            
            // Message End Detected
            if (c == 'B' && buffer_in[buffer_last_ii] == 'Y')
            {
                message_incoming = 0;
                message_in[message_ii] = '\0'; // Null-terminate the message
                //handle_message(message_ii);
               // printf("Third char: %c\n", message_in[2]);
              //  printf("Flag = %d", flag);
                // Format the response message
                read_Sensors();
                lux1 = ((uint16_t)datam[0] << 8) | datam[1];
                lux2 = ((uint16_t)datal[0] << 8) | datal[1];
                datam[0] = '\0';
                datam[1] = '\0';
                datal[0] = '\0';
                datal[1] = '\0';
                fill_string(message_out,'\0',MSGSIZE);
                if (flag)
                {
                    sprintf(message_out, "AZmhM%cS1%04uS2%04uL%cR%cYB", mode, update_lux1_average(scale_lux(lux1)), update_lux2_average(scale_lux(lux2)),  LB, RB);
                    //sprintf(message_out, "AZmhM%cS1%04uS2%04uL%cR%cYB", mode, s1, s2,  LB, RB);
                }
                else
                {
                    for (int i = 0; i < message_ii; i++)
                    {
                        message_out[i] = message_in[i];
                    }
                    printf("AZmhPIC:M=%c,LB=%c,RB=%cYB", mode, LB, RB);
                }
                if (!flag)
                {
                    flag = 1;
                }
                    // Send the response
                    for (int i = 0; message_out[i] != '\0'; i++)
                        {
                            while (!EUSART1_IsTxReady()); // Wait until ready
                            EUSART1_Write(message_out[i]);
                        }
                __delay_ms(500);
            }

            // Prevent Buffer Overflow
            if (message_ii >= MSGSIZE)
            {
                printf("AZmhPIC:messagetoolargeYB");
                message_incoming = 0;
            }
            
        }

        // Update mode, LB, and RB when detected
        if (buffer_in[buffer_last_ii] == 'M')
        {
            if((buffer_in[buffer_ii] == '0' || buffer_in[buffer_ii] == '1'))
            {
                mode = buffer_in[buffer_ii];
            }
            else
            {
                printf("AZmhPIC:BadDataForModeYB");
                message_incoming = 0;
                fill_string(message_in,'_',MSGSIZE);
            }
        }
        if (buffer_in[buffer_last_ii] == 'L')
        {
            if((buffer_in[buffer_ii] == '0' || buffer_in[buffer_ii] == '1'))
            {
                LB = buffer_in[buffer_ii];
            }
            else
            {
                printf("AZmhPIC:BadDataForLeftButtonYB");
                message_incoming = 0;
                fill_string(message_in,'_',MSGSIZE);
            }
        }
        if (buffer_in[buffer_last_ii] == 'R')
        {
            if((buffer_in[buffer_ii] == '0' || buffer_in[buffer_ii] == '1'))
            {
                RB = buffer_in[buffer_ii];
            }
            else
            {
                printf("AZmhPIC:BadDataForRightButtonYB");
                message_incoming = 0;
                fill_string(message_in,'_',MSGSIZE);
            }
        }
        
        buffer_last_ii = buffer_ii;
        buffer_ii = (buffer_ii + 1) % BUFSIZE;
    }
    if (Switch_GetValue() == LOW)
    {
        LED_SetHigh();
    }
    else
    {
        LED_SetLow();
    }
}
                
                
    //        printf("%s,%s",buffer_in,message_in);
           
         
//        if ((sec%3==0) & (sec!=sec_last)){
//            sprintf(message_out,"AZbaPIC: Heartbeat %u YB",sec);
//            send_message(message_out);
////            printf("AZbaPIC: Heartbeat %u YB",sec);
//        }
        
//        if (IO_RC2_GetValue()!=0)
//        {return 1;}
        
        sec_last = sec;
        ms_last = ms;
        __delay_ms(3000);
    }