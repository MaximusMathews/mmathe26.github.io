/*
 * VCNL4035X01_ALS.c
 *
 * Created  : 9 November 2020
 * Modified : 6 May 2021
 * Author   : HWanyusof
 * Version	: 1.0
 */

#include "VCNL4035X01_Prototypes.h"
#include "VCNL4035X01.h"
#include "mcc_generated_files/i2c_host/mssp1.h"
#include "VCNL4035X01_Application_Library.h"


extern int I2C_Bus;

//****************************************************************************************************
//*****************************************Sensor API*************************************************

/* Helper function to read a register */
static bool VCNL4035X01_ReadRegister(uint8_t reg, uint8_t *data, size_t length) {
    if (!I2C1_WriteRead(VCNL4035X01_SlaveAddress, &reg, 1, data, length)) {
        printf("I2C Read failed for register 0x%02X\n", reg);
        return false;
    }
    return true;
}

/* Helper function to write to a register */
static bool VCNL4035X01_WriteRegister(uint8_t reg, uint8_t *data, size_t length) {
    uint8_t buffer[length + 1];
    buffer[0] = reg;
    for (size_t i = 0; i < length; i++) {
        buffer[i + 1] = data[i];
    }
    if (!I2C1_Write(VCNL4035X01_SlaveAddress, buffer, length + 1)) {
        printf("I2C Write failed for register 0x%02X\n", reg);
        return false;
    }
    return true;
}

/* Turn On/Off the ALS Sensor */
void VCNL4035X01_SET_ALS_SD(uint8_t SD_Bit) {
    uint8_t data[2];
    if (!VCNL4035X01_ReadRegister(VCNL4035X01_ALS_CONF_1, data, 2)) return;

    data[0] = (data[0] & ~(VCNL4035X01_ALS_SD_EN | VCNL4035X01_ALS_SD_DIS)) | SD_Bit;

    VCNL4035X01_WriteRegister(VCNL4035X01_ALS_CONF_1, data, 2);
}

/* Set the Integration Time */
void VCNL4035X01_SET_ALS_IT(uint8_t IntTime) {
    uint8_t data[2];
    if (!VCNL4035X01_ReadRegister(VCNL4035X01_ALS_CONF_1, data, 2)) return;

    data[0] = (data[0] & ~(VCNL4035X01_ALS_IT_50MS | VCNL4035X01_ALS_IT_100MS |
                           VCNL4035X01_ALS_IT_200MS | VCNL4035X01_ALS_IT_400MS |
                           VCNL4035X01_ALS_IT_800MS)) |
              IntTime;

    VCNL4035X01_WriteRegister(VCNL4035X01_ALS_CONF_1, data, 2);
}

/* Set the Typical Dynamic Range */
void VCNL4035X01_SET_ALS_HD(uint8_t HD) {
    uint8_t data[2];
    if (!VCNL4035X01_ReadRegister(VCNL4035X01_ALS_CONF_1, data, 2)) return;

    data[0] = (data[0] & ~(VCNL4035X01_ALS_HD_X1 | VCNL4035X01_ALS_HD_X2)) | HD;

    VCNL4035X01_WriteRegister(VCNL4035X01_ALS_CONF_1, data, 2);
}

/* Set the Persistence */
void VCNL4035X01_SET_ALS_PERS(uint8_t Pers) {
    uint8_t data[2];
    if (!VCNL4035X01_ReadRegister(VCNL4035X01_ALS_CONF_1, data, 2)) return;

    data[0] = (data[0] & ~(VCNL4035X01_ALS_PERS_1 | VCNL4035X01_ALS_PERS_2 |
                           VCNL4035X01_ALS_PERS_4 | VCNL4035X01_ALS_PERS_8)) |
              Pers;

    VCNL4035X01_WriteRegister(VCNL4035X01_ALS_CONF_1, data, 2);
}

/* Enable/Disable Interrupt */
void VCNL4035X01_SET_ALS_Interrupt(uint8_t Interrupt) {
    uint8_t data[2];
    if (!VCNL4035X01_ReadRegister(VCNL4035X01_ALS_CONF_1, data, 2)) return;

    data[0] = (data[0] & ~(VCNL4035X01_ALS_INT_EN | VCNL4035X01_ALS_INT_DIS)) | Interrupt;

    VCNL4035X01_WriteRegister(VCNL4035X01_ALS_CONF_1, data, 2);
}

/* Set the ALS Sensitivity
 *VCNL4035X01_SET_ALS_NS(Byte ALS_NS)
 *Byte ALS_NS - Input Parameter:
 *
 * VCNL4035X01_ALS_NS_X1
 * VCNL4035X01_ALS_NS_X2
 */
void VCNL4035X01_SET_ALS_NS(Byte ALS_NS)
{
	struct TransferData VCNL4035X01_Data;
	VCNL4035X01_Data.Slave_Address = VCNL4035X01_SlaveAddress;
	VCNL4035X01_Data.RegisterAddress = VCNL4035X01_ALS_CONF_2;
	VCNL4035X01_Data.Select_I2C_Bus = I2C_Bus;
	ReadI2C_Bus(&VCNL4035X01_Data);
	VCNL4035X01_Data.WData[0]=VCNL4035X01_Data.RData[0];
	VCNL4035X01_Data.WData[1] = (VCNL4035X01_Data.RData[1]&~(VCNL4035X01_ALS_NS_X1|VCNL4035X01_ALS_NS_X2))|ALS_NS;
	WriteI2C_Bus(&VCNL4035X01_Data);
}

/* Turn On/Off the White Channel
 *VCNL4035X01_SET_WHITE_SD(Byte WhiteSD)
 *Byte WhiteSD - Input Parameter:
 *
 * VCNL4035X01_ALS_WHITE_SD_EN
 * VCNL4035X01_ALS_WHITE_SD_DIS
 */
void VCNL4035X01_SET_WHITE_SD(Byte WhiteSD)
{
	struct TransferData VCNL4035X01_Data;
	VCNL4035X01_Data.Slave_Address = VCNL4035X01_SlaveAddress;
	VCNL4035X01_Data.RegisterAddress = VCNL4035X01_ALS_CONF_2;
	VCNL4035X01_Data.Select_I2C_Bus = I2C_Bus;
	ReadI2C_Bus(&VCNL4035X01_Data);
	VCNL4035X01_Data.WData[0]=VCNL4035X01_Data.RData[0];
	VCNL4035X01_Data.WData[1] = (VCNL4035X01_Data.RData[1]&~(VCNL4035X01_ALS_WHITE_SD_EN|VCNL4035X01_ALS_WHITE_SD_DIS))|WhiteSD;
	WriteI2C_Bus(&VCNL4035X01_Data);
}

/* Read the ALS Data */
uint16_t VCNL4035X01_GET_ALS_Data() {
    uint8_t data[2];
    if (!VCNL4035X01_ReadRegister(VCNL4035X01_ALS_DATA, data, 2)) return 0;

    return ((uint16_t)data[1] << 8) | data[0];
}

/* Read the White Channel Data
 *VCNL4035X01_GET_White_Data() returns White Data between 0d0 and 0d65535
 */
Word VCNL4035X01_GET_White_Data()
{
	struct TransferData VCNL4035X01_Data;
	VCNL4035X01_Data.Slave_Address = VCNL4035X01_SlaveAddress;
	VCNL4035X01_Data.RegisterAddress = VCNL4035X01_WHITE_DATA;
	VCNL4035X01_Data.Select_I2C_Bus = I2C_Bus;
	ReadI2C_Bus(&VCNL4035X01_Data);
	return ((VCNL4035X01_Data.RData[1]<<8)|VCNL4035X01_Data.RData[0]);
}

/* Set the Low Threshold */
void VCNL4035X01_SET_ALS_LowThreshold(uint16_t LowThreshold) {
    uint8_t data[2] = {LowThreshold & 0xFF, (LowThreshold >> 8) & 0xFF};
    VCNL4035X01_WriteRegister(VCNL4035X01_ALS_THDL, data, 2);
}

/* Set the High Threshold */
void VCNL4035X01_SET_ALS_HighThreshold(uint16_t HighThreshold) {
    uint8_t data[2] = {HighThreshold & 0xFF, (HighThreshold >> 8) & 0xFF};
    VCNL4035X01_WriteRegister(VCNL4035X01_ALS_THDH, data, 2);
}

/* Read the ALS Interrupt Flag */
uint8_t VCNL4035X01_GET_ALS_Interrupt() {
    uint8_t data[2];
    if (!VCNL4035X01_ReadRegister(VCNL4035X01_INT_FLAG, data, 2)) return 0;

    return data[1];
}

/* Read the ALS_SD bit
 *returns 1 for Shutdown and 0 for ALS On
 */
bool VCNL4035X01_GET_ALS_SD_Bit()
{
	struct TransferData VCNL4035X01_Data;
	VCNL4035X01_Data.Slave_Address = VCNL4035X01_SlaveAddress;
	VCNL4035X01_Data.RegisterAddress = VCNL4035X01_ALS_CONF_1;
    VCNL4035X01_Data.Select_I2C_Bus = I2C_Bus;
	ReadI2C_Bus(&VCNL4035X01_Data);
	if ((VCNL4035X01_Data.RData[0] & 0x01) == 0x01) {return 1;}
	else
	return 0;
}

/* Read the WHITE_SD bit
 *returns 1 for White Mode and 0 for White Mode Disable (Normal ALS)
 */
bool VCNL4035X01_GET_WHITE_SD_Bit()
{
	struct TransferData VCNL4035X01_Data;
	VCNL4035X01_Data.Slave_Address = VCNL4035X01_SlaveAddress;
	VCNL4035X01_Data.RegisterAddress = VCNL4035X01_ALS_CONF_2;
    VCNL4035X01_Data.Select_I2C_Bus = I2C_Bus;
	ReadI2C_Bus(&VCNL4035X01_Data);
	if ((VCNL4035X01_Data.RData[1] & 0x01) == 0x01) {return 1;}
	else
	return 0;
}