#include "VCNL4035X01_Prototypes.h"
#include "VCNL4035X01.h"
#include "mcc_generated_files/i2c_host/mssp1.h"
#include "VCNL4035X01_Application_Library.h"

//****************************************************************************************************
//***************************************Application API**********************************************

/* Helper function to read a register */
static bool VCNL4035X01_ReadRegister(uint8_t reg, uint8_t *data, size_t length) {
    if (!I2C1_WriteRead(VCNL4035X01_SlaveAddress, &reg, 1, data, length)) {
        printf("I2C Read failed for register 0x%02X\n", reg);
        return false;
    }
    return true;
}

/* Helper function to write to a register */
static bool VCNL4035X01_WriteRegister(uint8_t reg, uint8_t *data, size_t length) {
    uint8_t buffer[length + 1];
    buffer[0] = reg;
    for (size_t i = 0; i < length; i++) {
        buffer[i + 1] = data[i];
    }
    if (!I2C1_Write(VCNL4035X01_SlaveAddress, buffer, length + 1)) {
        printf("I2C Write failed for register 0x%02X\n", reg);
        return false;
    }
    return true;
}

/* Reset the Sensor to the default value */
void Reset_Sensor() {
    uint8_t data[2];

    // Reset ALS_CONF_1
    data[0] = 0x01;
    data[1] = 0x01;
    VCNL4035X01_WriteRegister(VCNL4035X01_ALS_CONF_1, data, 2);

    // Reset ALS_THDL
    data[0] = 0x00;
    data[1] = 0x00;
    VCNL4035X01_WriteRegister(VCNL4035X01_ALS_THDL, data, 2);

    // Reset ALS_THDH
    data[0] = 0x00;
    data[1] = 0x00;
    VCNL4035X01_WriteRegister(VCNL4035X01_ALS_THDH, data, 2);

    // Reset PS_CONF_1
    data[0] = 0x01;
    data[1] = 0x00;
    VCNL4035X01_WriteRegister(VCNL4035X01_PS_CONF_1, data, 2);

    // Reset PS_CONF_3
    data[0] = 0x00;
    data[1] = 0x00;
    VCNL4035X01_WriteRegister(VCNL4035X01_PS_CONF_3, data, 2);

    // Reset PS_CANC
    data[0] = 0x00;
    data[1] = 0x00;
    VCNL4035X01_WriteRegister(VCNL4035X01_PS_CANC, data, 2);

    // Reset PS_THDL
    data[0] = 0x00;
    data[1] = 0x00;
    VCNL4035X01_WriteRegister(VCNL4035X01_PS_THDL, data, 2);

    // Reset PS_THDH
    data[0] = 0x00;
    data[1] = 0x00;
    VCNL4035X01_WriteRegister(VCNL4035X01_PS_THDH, data, 2);

    // Reset INT_FLAG
    data[0] = 0x00;
    data[1] = 0x00;
    VCNL4035X01_WriteRegister(VCNL4035X01_INT_FLAG, data, 2);
}

/* Get ALS Mode */
int VCNL4035X01_GET_ALS_Mode() {
    uint8_t data[2];
    int mode = -1;

    // Read ALS_SD bit
    if (VCNL4035X01_ReadRegister(VCNL4035X01_ALS_CONF_1, data, 2)) {
        if (data[0] & 0x01) {
            mode = 0; // ALS Shutdown Mode
        } else if (!(data[1] & 0x01)) {
            mode = 1; // ALS Mode
        } else {
            mode = 2; // White Channel Mode
        }
    }
    return mode;
}

/* Get Proximity Mode */
int VCNL4035X01_GET_PS_Mode() {
    uint8_t data[2];
    int mode = -1;

    // Read PS_SD and PS_AF bits
    if (VCNL4035X01_ReadRegister(VCNL4035X01_PS_CONF_1, data, 2)) {
        if (data[0] & 0x01) {
            mode = 0; // PS Shutdown Mode
        } else if (!(data[1] & 0x01)) {
            mode = 1; // Auto/Self-Timed Mode
        } else {
            mode = 2; // Active Force Mode
        }
    }
    return mode;
}

/* Calculate ALS Lux */
float VCNL4035X01_CAL_Lux(float sensitivity, float count) {
    return sensitivity * count;
}

/* Get ALS Data */
uint16_t VCNL4035X01_GET_ALS_Data() {
    uint8_t data[2];
    if (!VCNL4035X01_ReadRegister(VCNL4035X01_ALS_DATA, data, 2)) {
        return 0;
    }
    return ((uint16_t)data[1] << 8) | data[0];
}

/* Get Delay for Measurement */
int VCNL4035X01_GET_Delay(uint8_t ALS_IT) {
    switch (ALS_IT) {
        case VCNL4035X01_ALS_IT_50MS: return 60;
        case VCNL4035X01_ALS_IT_100MS: return 110;
        case VCNL4035X01_ALS_IT_200MS: return 210;
        case VCNL4035X01_ALS_IT_400MS: return 410;
        case VCNL4035X01_ALS_IT_800MS: return 810;
        default: return 0;
    }
}