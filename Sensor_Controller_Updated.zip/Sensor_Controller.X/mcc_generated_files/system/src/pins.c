/**
 * Generated Driver File
 * 
 * @file pins.c
 * 
 * @ingroup  pinsdriver
 * 
 * @brief This is generated driver implementation for pins. 
 *        This file provides implementations for pin APIs for all pins selected in the GUI.
 *
 * @version Driver Version 3.1.1
*/

/*
? [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#include "../pins.h"

void (*IO_RB2_InterruptHandler)(void);
void (*IO_RC7_InterruptHandler)(void);

void PIN_MANAGER_Initialize(void)
{
   /**
    LATx registers
    */
    LATA = 0x0;
    LATB = 0x3C;
    LATC = 0x1;
    /**
    ODx registers
    */
    ODCONA = 0x0;
    ODCONB = 0x14;
    ODCONC = 0x0;

    /**
    TRISx registers
    */
    TRISA = 0xFE;
    TRISB = 0xFF;
    TRISC = 0xFD;

    /**
    ANSELx registers
    */
    ANSELA = 0xFE;
    ANSELB = 0xC3;
    ANSELC = 0x7C;

    /**
    WPUx registers
    */
    WPUA = 0x0;
    WPUB = 0x0;
    WPUC = 0x0;
    WPUE = 0x0;


    /**
    SLRCONx registers
    */
    SLRCONA = 0xFF;
    SLRCONB = 0xFF;
    SLRCONC = 0xFF;

    /**
    INLVLx registers
    */
    INLVLA = 0xFF;
    INLVLB = 0xFF;
    INLVLC = 0xFF;
    INLVLE = 0x8;

   /**
    RxyI2C | RxyFEAT registers   
    */
    /**
    PPS registers
    */
    RX1PPS = 0x17; //RC7->EUSART1:RX1;
    RC1PPS = 0x09;  //RC1->EUSART1:TX1;
    SSP2CLKPPS = 0xB;  //RB3->MSSP2:SCL2;
    RB3PPS = 0x11;  //RB3->MSSP2:SCL2;
    SSP2DATPPS = 0xA;  //RB2->MSSP2:SDA2;
    RB2PPS = 0x12;  //RB2->MSSP2:SDA2;
    SSP1CLKPPS = 0xD;  //RB5->MSSP1:SCL1;
    RB5PPS = 0x0F;  //RB5->MSSP1:SCL1;
    SSP1DATPPS = 0xC;  //RB4->MSSP1:SDA1;
    RB4PPS = 0x10;  //RB4->MSSP1:SDA1;

   /**
    IOCx registers 
    */
    IOCAP = 0x0;
    IOCAN = 0x0;
    IOCAF = 0x0;
    IOCBP = 0x0;
    IOCBN = 0x4;
    IOCBF = 0x0;
    IOCCP = 0x0;
    IOCCN = 0x80;
    IOCCF = 0x0;
    IOCEP = 0x0;
    IOCEN = 0x0;
    IOCEF = 0x0;

    IO_RB2_SetInterruptHandler(IO_RB2_DefaultInterruptHandler);
    IO_RC7_SetInterruptHandler(IO_RC7_DefaultInterruptHandler);

    // Enable PIE0bits.IOCIE interrupt 
    PIE0bits.IOCIE = 1; 
}
  
void PIN_MANAGER_IOC(void)
{
    // interrupt on change for pin IO_RB2
    if(IOCBFbits.IOCBF2 == 1)
    {
        IO_RB2_ISR();  
    }
    // interrupt on change for pin IO_RC7
    if(IOCCFbits.IOCCF7 == 1)
    {
        IO_RC7_ISR();  
    }
}
   
/**
   IO_RB2 Interrupt Service Routine
*/
void IO_RB2_ISR(void) {

    // Add custom IO_RB2 code

    // Call the interrupt handler for the callback registered at runtime
    if(IO_RB2_InterruptHandler)
    {
        IO_RB2_InterruptHandler();
    }
    IOCBFbits.IOCBF2 = 0;
}

/**
  Allows selecting an interrupt handler for IO_RB2 at application runtime
*/
void IO_RB2_SetInterruptHandler(void (* InterruptHandler)(void)){
    IO_RB2_InterruptHandler = InterruptHandler;
}

/**
  Default interrupt handler for IO_RB2
*/
void IO_RB2_DefaultInterruptHandler(void){
    // add your IO_RB2 interrupt custom code
    // or set custom function using IO_RB2_SetInterruptHandler()
}
   
/**
   IO_RC7 Interrupt Service Routine
*/
void IO_RC7_ISR(void) {

    // Add custom IO_RC7 code

    // Call the interrupt handler for the callback registered at runtime
    if(IO_RC7_InterruptHandler)
    {
        IO_RC7_InterruptHandler();
    }
    IOCCFbits.IOCCF7 = 0;
}

/**
  Allows selecting an interrupt handler for IO_RC7 at application runtime
*/
void IO_RC7_SetInterruptHandler(void (* InterruptHandler)(void)){
    IO_RC7_InterruptHandler = InterruptHandler;
}

/**
  Default interrupt handler for IO_RC7
*/
void IO_RC7_DefaultInterruptHandler(void){
    // add your IO_RC7 interrupt custom code
    // or set custom function using IO_RC7_SetInterruptHandler()
}
/**
 End of File
*/